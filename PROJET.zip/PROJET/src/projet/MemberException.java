/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet;

/**
 * On répertorie tous les blindages à faire pour la classe member
 * @author Tommy
 */
public class MemberException extends Exception {
    
    public MemberException(String message)
    {
        super(message);
    }
}
