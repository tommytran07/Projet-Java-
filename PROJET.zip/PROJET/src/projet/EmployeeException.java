/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet;

/**
 *
 * @author Tommy
 */
public class EmployeeException extends Exception {
    
    public EmployeeException(String message) {
        super(message);
    }
}
